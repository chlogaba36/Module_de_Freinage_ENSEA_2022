/*
 * Button.h
 *
 *  Created on: May 24, 2022
 *      Author: chlogaba36
 */

#ifndef SRC_BUTTON_H_
#define SRC_BUTTON_H_

void BUTTON_Init(void);
int BUTTON_GetLevel(void);

#endif /* SRC_BUTTON_H_ */
